/*
 * Copyright 2004-2007 the Seasar Foundation and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, 
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package org.seasar.fisshplate.core;

import java.lang.reflect.InvocationTargetException;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.Region;
import org.seasar.fisshplate.context.FPContext;

/**
 * セル要素の基底抽象クラスです。
 * @author rokugen
 *
 */
public abstract class AbstractCell implements TemplateElement {
	/**
	 * テンプレート側のセル
	 */
	protected HSSFCell templateCell;
	private boolean isMergedCell;
	private short relativeMergedColumnTo;
	private int relativeMergedRowNumTo;
	

	/**
	 * コンストラクタです。
	 * 
	 * @param templateCell
	 */
	AbstractCell( HSSFSheet templateSheet,HSSFCell templateCell,int rowNum) {
		this.templateCell = templateCell;
		//マージ情報をなめて、スタート地点が合致すれば保存しておく。
		for(int i=0; i < templateSheet.getNumMergedRegions();i++){
			Region reg = templateSheet.getMergedRegionAt(i);
			setUpMergedCellInfo(templateCell.getCellNum(), rowNum, reg);
			if(isMergedCell){
				break;
			}
		}
	}
	
	private void setUpMergedCellInfo(short cellNum, int rowNum, Region reg){
		if(reg.getColumnFrom() != cellNum || reg.getRowFrom() != rowNum){
			isMergedCell = false;
			return;
		}						
		isMergedCell = true;
		relativeMergedColumnTo = (short) (reg.getColumnTo() - reg.getColumnFrom());
		relativeMergedRowNumTo = reg.getRowTo() - reg.getRowFrom();
	}	
	

	/**
	 * テンプレート側のセルのスタイルを出力側へコピーします。フォントやデータフォーマットも反映されます。
	 * @param context コンテキスト
	 * @param outCell 出力するセル
	 */
	protected void copyCellStyle(FPContext context, HSSFCell outCell) {

		HSSFWorkbook outWb = context.getOutWorkBook();
		HSSFCellStyle outStyle = outWb.createCellStyle();
		HSSFCellStyle templateStyle = templateCell.getCellStyle(); 
		copyProperties(outStyle, templateStyle);

		HSSFFont font = getCopiedFont(context, outWb);
		outStyle.setFont(font);
		
		copyDataFormat(context, templateStyle, outStyle,outWb); 
		
		outCell.setCellStyle(outStyle);
		if(isMergedCell){
			mergeCell(context, outWb);
		}
		
	}

	private HSSFFont getCopiedFont(FPContext context, HSSFWorkbook outWb) {
		short fontIndex = templateCell.getCellStyle().getFontIndex();
		HSSFFont font = outWb.createFont();
		copyProperties(font, context.getTemplate().getFontAt(fontIndex));
		return font;
	}
	
	private void copyDataFormat(FPContext context, HSSFCellStyle templateStyle,HSSFCellStyle outStyle,HSSFWorkbook outWb){
		short dfIdx =  templateStyle.getDataFormat();
		HSSFWorkbook templateWb = context.getTemplate();
		HSSFDataFormat templateDf = templateWb.createDataFormat();
		HSSFDataFormat outDf = outWb.createDataFormat();
		short outDfIdx = outDf.getFormat(templateDf.getFormat(dfIdx));
		outStyle.setDataFormat(outDfIdx);
	}

	private void copyProperties(Object dest, Object src) {
		try {
			BeanUtils.copyProperties(dest, src);
		} catch (IllegalAccessException e) {
			throw new RuntimeException(e);
		} catch (InvocationTargetException e) {
			throw new RuntimeException(e);
		}
	}
	
	private void mergeCell(FPContext context, HSSFWorkbook wb){		
		short columnFrom = context.getCurrentCellNum();
		int rowFrom = context.getCurrentRowNum();
		
		Region reg = new Region();
		reg.setColumnFrom(columnFrom);
		reg.setColumnTo((short) (columnFrom + relativeMergedColumnTo));
		reg.setRowFrom(rowFrom);
		reg.setRowTo(rowFrom + relativeMergedRowNumTo);
		wb.getSheetAt(0).addMergedRegion(reg);		
	}

}
